#pragma once

void EncoderInit (void);
int32_t getKey (void);