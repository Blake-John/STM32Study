#ifndef __LED_H
#define __LED_H

void LED_Init (void);
void LED0_ON (void);
void LED0_OFF (void);
void LED0_REVERSE (void);
void LED3_ON (void);
void LED3_OFF (void);
void LED3_REVERSE (void);

#endif
