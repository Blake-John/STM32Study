#ifndef __KEY_H
#define __KEY_H

void KeyInit (void);
int8_t getNum (void);

#endif
